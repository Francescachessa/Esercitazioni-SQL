DROP SCHEMA IF EXISTS toysgroup_chessa_francesca;
CREATE SCHEMA toysgroup_CHESSA_FRANCESCA;
-- REFRESH SCHEMA AND SET AS DEFAULT SCHEMA
-- CREAZIONE TABELLE

CREATE TABLE PRODUCT (
    product_id INT NOT NULL UNIQUE,
    product_name VARCHAR(50),
    unit_price FLOAT,
    category VARCHAR(50),
    PRIMARY KEY (product_id)
);

CREATE TABLE REGION (
    region_id INT NOT NULL UNIQUE,
    region_name VARCHAR(50),
    PRIMARY KEY (region_id)
);

CREATE TABLE SALE (
    sale_id INT NOT NULL UNIQUE,
    product_id INT NOT NULL,
    region_id INT NOT NULL,
    sale_date DATE,
    quantity INT,
    unit_price FLOAT,
    tot_price FLOAT AS (unit_price * quantity),
    PRIMARY KEY (sale_id),
    FOREIGN KEY (product_id)
        REFERENCES PRODUCT (product_id),
    FOREIGN KEY (region_id)
        REFERENCES REGION (region_id)
);

-- POPOLAMENTO TABELLE

INSERT INTO product (product_id, product_name, unit_price, category) VALUES
(1,'Lego Marvel',95.99,'Lego'),
(2,'Barbie',69.90, 'Dolls'),
(3,'Monster High',49.99,'Dolls'),
(4,'Lego ninja',159.99,'Lego'),
(5,'Lego Jurassic World',139.99,'Lego'),
(6,'Pluto trainabile',99.99,'Disney Junior'),
(7,'Stich peluche',89.80,'Disney Junior'),
(8,'Eilik B',287.99,'Robots'),
(9,'Robot Spy Bot',49.99,'Robots'),
(10,'Hasbro Capitan America',47.99,'Action Figures');
SELECT * FROM product;

INSERT INTO region (region_id, region_name) VALUES
(1,'Italy'),
(2,'Spain'),
(3,'France'),
(4,'Portugal');
SELECT * FROM region;

INSERT INTO SALE (sale_id,product_id,region_id,sale_date,quantity, unit_price) VALUES
(1,5,3,'2022-05-21',1,139.99),
(2,4,3,'2022-06-08',2,159.99),
(3,9,4,'2023-02-13',1,49.99),
(4,2,4,'2023-05-04',1,69.90),
(5,6,1,'2022-03-23',5,99.99),
(6,7,1,'2022-07-10',4,89.80),
(7,3,2,'2023-04-06',2,49.99),
(8,3,1,'2023-05-07',4,49.99);
SELECT * FROM sale;

/* 1. Verificare che i campi definiti come PK siano univoci.
metodo n1: utilizzando il comando 'show columns' è possibile visualizzare tutte le specifiche 
di ogni campo della tabella scelta, tra cui la chiave primaria. */ 

SHOW COLUMNS FROM product;
SHOW COLUMNS FROM region;
SHOW COLUMNS FROM sale;

-- metodo n2: in alternativa per confermare che le pk siano univoche, si cercano i duplicati.
SELECT 
    sale_id, COUNT(sale_id)
FROM
    sale
GROUP BY sale_id
HAVING COUNT(sale_id) > 1;

SELECT 
    product_id, COUNT(product_id)
FROM
    product
GROUP BY product_id
HAVING COUNT(product_id) > 1;

SELECT 
    region_id, COUNT(region_id)
FROM
    region
GROUP BY region_id
HAVING COUNT(region_id) > 1;             -- non ci sono.

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT 
    p.product_name,
    YEAR(s.sale_date) year,
    CAST(SUM(s.tot_price) AS DECIMAL (10 , 2 )) total_amount
FROM
    product p
        JOIN
    sale s ON p.product_id = s.product_id
GROUP BY 1 , 2;

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT 
    CAST(SUM(s.tot_price) AS DECIMAL (10 , 2 )) total_amount,
    r.region_name region,
    YEAR(s.sale_date) year
FROM
    sale s
        JOIN
    region r ON s.region_id = r.region_id
GROUP BY 2 , 3
ORDER BY 3 , 1 DESC;

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT 
    p.category,
    SUM(s.quantity) sold_quantity,
    CAST(SUM(s.tot_price) AS DECIMAL (10 , 2 )) tot_amount
FROM
    product p
        JOIN
    sale s ON p.product_id = s.product_id
GROUP BY p.category
ORDER BY 2 DESC
LIMIT 1;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- metodo n1: esclusione di tutti i product_id presenti tabella sale, selezionando solo i restanti attraverso il nome nella tabella product.
SELECT 
    product_name unsold_product
FROM
    product
WHERE
    product_id NOT IN (SELECT 
            product_id
        FROM
            sale);

-- metodo n2: selezione di tutte le righe risultanti NULL dall'unione (left outer join) di product e sale.
SELECT DISTINCT
    p.product_name unsold_product
FROM
    product p
        LEFT JOIN
    sale s ON p.product_id = s.product_id
WHERE
    s.sale_id IS NULL;
    
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    p.product_name, s.product_id, MAX(s.sale_date) latest_date
FROM
    sale s
        JOIN
    product p ON s.product_id = p.product_id
GROUP BY 1 , 2;